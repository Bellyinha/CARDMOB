import { useState } from 'react'
import './App.css'
import ProductList from './components/ProductList'

function App() {

  return (
    <>
      <ProductList />
    </>
  )
}

export default App
